<?php

use Illuminate\Database\Seeder;

class TeachersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('teachers')->insert([
        	'name' => 'Bambang',
        	'email' => 'bambang@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Hartono',
        	'email' => 'hartono@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Sugiarto',
        	'email' => 'sugiarto@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Siti',
        	'email' => 'siti@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Endang',
        	'email' => 'endang@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Cahyono',
        	'email' => 'cahyono@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Triyana',
        	'email' => 'triyana@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Wulandari',
        	'email' => 'wulandari@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Sulis',
        	'email' => 'sulis@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
        DB::table('teachers')->insert([
        	'name' => 'Budianto',
        	'email' => 'budianto@gmail.com',
            'password' => '$2y$10$HdgnXmJuB2aFE/iysHhV4us.dFt2hqMkRRRMxwbqYlE4F1tAbHt3e',
            'institution_id' => '1'
        ]);
    }
}
