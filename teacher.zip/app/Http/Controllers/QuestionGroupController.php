<?php

namespace App\Http\Controllers;

use App\QuestionGroup;
use Illuminate\Http\Request;

class QuestionGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tests = QuestionGroup::all();
        return view('tests.index',compact('tests'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tests.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\QuestionGroup  $questionGroup
     * @return \Illuminate\Http\Response
     */
    // public function show(QuestionGroup $questionGroup)
    public function show($id)
    {
        $test = QuestionGroup::find($id);
        return view('tests.show',compact('test'));
        // return view('tests.take',compact('test'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\QuestionGroup  $questionGroup
     * @return \Illuminate\Http\Response
     */
    // public function show(QuestionGroup $questionGroup)
    public function take($id)
    {
        $test = QuestionGroup::find($id);
        $questions = QuestionGroup::find($id)->questions;
        // dd($questions);
        return view('tests.take',compact(['test','questions']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\QuestionGroup  $questionGroup
     * @return \Illuminate\Http\Response
     */
    public function edit(QuestionGroup $questionGroup)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\QuestionGroup  $questionGroup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, QuestionGroup $questionGroup)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\QuestionGroup  $questionGroup
     * @return \Illuminate\Http\Response
     */
    public function destroy(QuestionGroup $questionGroup)
    {
        //
    }
}
