<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nav extends Model
{
    //
}
