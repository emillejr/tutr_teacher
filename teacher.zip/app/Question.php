<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\QuestionGroup;

class Question extends Model
{
    public function group() {
    	return $this->belongsTo('QuestionGroup');
    }
}
