<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Question;
use App\QuestionType;
use App\Topic;
use App\Teacher;

class QuestionGroup extends Model
{
    public function questions() {
    	return $this->hasMany('App\Question','group_id');
    }

    public function question_type() {
    	return $this->belongsTo(QuestionType::class);
    }

    public function topic() {
    	return $this->belongsTo(Topic::class);
    }

    public function teacher() {
    	return $this->belongsTo(Teacher::class);
    }

}
